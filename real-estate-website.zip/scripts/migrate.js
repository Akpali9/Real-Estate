const mysql = require("mysql2/promise")
const fs = require("fs")
const path = require("path")

// Database connection
async function createConnection() {
  return await mysql.createConnection({
    uri: process.env.DATABASE_URL,
  })
}

async function runMigrations() {
  let connection

  try {
    console.log("🚀 Starting database migrations...")

    connection = await createConnection()

    // Read migration file
    const migrationPath = path.join(__dirname, "../lib/db/migrations/001_initial_schema.sql")
    const migrationSQL = fs.readFileSync(migrationPath, "utf8")

    // Split SQL statements (MySQL doesn't support multiple statements in one query by default)
    const statements = migrationSQL
      .split(";")
      .map((stmt) => stmt.trim())
      .filter((stmt) => stmt.length > 0 && !stmt.startsWith("--"))

    // Execute each statement
    for (const statement of statements) {
      if (statement.trim()) {
        await connection.execute(statement)
      }
    }

    console.log("✅ Database migrations completed successfully!")
    console.log("📊 Created tables:")
    console.log("   - users")
    console.log("   - properties")
    console.log("   - inquiries")
    console.log("   - reviews")
    console.log("   - favorites")
    console.log("🔧 Created indexes and triggers for optimal performance")
  } catch (error) {
    console.error("❌ Migration failed:", error)
    process.exit(1)
  } finally {
    if (connection) {
      await connection.end()
    }
  }
}

// Run migrations
runMigrations()
