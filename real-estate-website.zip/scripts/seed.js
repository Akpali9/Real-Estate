const mysql = require("mysql2/promise")
const bcrypt = require("bcryptjs")

// Database connection
async function createConnection() {
  return await mysql.createConnection({
    uri: process.env.DATABASE_URL,
  })
}

async function seedDatabase() {
  let connection

  try {
    console.log("🌱 Starting database seeding...")

    connection = await createConnection()

    // Create admin user
    const adminPassword = await bcrypt.hash("admin123", 12)
    await connection.execute(
      `
      INSERT INTO users (email, password, name, role, phone, bio) 
      VALUES (?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE name = VALUES(name)
    `,
      ["admin@realestatepro.com", adminPassword, "Admin User", "admin", "(555) 123-4567", "System Administrator"],
    )

    // Create agent user
    const agentPassword = await bcrypt.hash("agent123", 12)
    const [agentResult] = await connection.execute(
      `
      INSERT INTO users (email, password, name, role, phone, bio, license_number, years_experience, specializations) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE name = VALUES(name)
    `,
      [
        "sarah@realestatepro.com",
        agentPassword,
        "Sarah Johnson",
        "agent",
        "(555) 987-6543",
        "Experienced real estate agent specializing in residential properties and first-time home buyers.",
        "RE123456789",
        8,
        JSON.stringify(["Residential", "First-time Buyers", "Luxury Homes"]),
      ],
    )

    // Get agent ID for properties
    const [agentRows] = await connection.execute("SELECT id FROM users WHERE email = ?", ["sarah@realestatepro.com"])
    const agentId = agentRows[0].id

    // Create sample properties
    const properties = [
      {
        title: "Beautiful Family Home in Suburbia",
        description:
          "This stunning 4-bedroom, 3-bathroom home features an open floor plan, modern kitchen with granite countertops, and a spacious backyard perfect for entertaining. Located in a quiet neighborhood with excellent schools.",
        price: 450000,
        property_type: "house",
        listing_type: "sale",
        bedrooms: 4,
        bathrooms: 3,
        square_feet: 2500,
        lot_size: 0.25,
        year_built: 2015,
        address: "123 Maple Street",
        city: "Springfield",
        state: "IL",
        zip_code: "62701",
        latitude: 39.7817,
        longitude: -89.6501,
        images: JSON.stringify(["/placeholder.svg?height=400&width=600"]),
        features: JSON.stringify([
          "Granite Countertops",
          "Hardwood Floors",
          "Two-Car Garage",
          "Fenced Yard",
          "Central Air",
        ]),
      },
      {
        title: "Modern Downtown Condo",
        description:
          "Luxury 2-bedroom condo in the heart of downtown. Floor-to-ceiling windows, stainless steel appliances, and building amenities including gym and rooftop deck.",
        price: 320000,
        property_type: "condo",
        listing_type: "sale",
        bedrooms: 2,
        bathrooms: 2,
        square_feet: 1200,
        year_built: 2020,
        address: "456 Downtown Plaza",
        city: "Springfield",
        state: "IL",
        zip_code: "62702",
        latitude: 39.799,
        longitude: -89.644,
        images: JSON.stringify(["/placeholder.svg?height=400&width=600"]),
        features: JSON.stringify(["City Views", "Stainless Appliances", "Gym Access", "Rooftop Deck", "Concierge"]),
      },
      {
        title: "Charming Victorian Rental",
        description:
          "Historic 3-bedroom Victorian home available for rent. Original hardwood floors, high ceilings, and period details throughout. Walking distance to parks and shopping.",
        price: 2200,
        property_type: "house",
        listing_type: "rent",
        bedrooms: 3,
        bathrooms: 2,
        square_feet: 1800,
        year_built: 1895,
        address: "789 Historic Avenue",
        city: "Springfield",
        state: "IL",
        zip_code: "62703",
        latitude: 39.79,
        longitude: -89.66,
        images: JSON.stringify(["/placeholder.svg?height=400&width=600"]),
        features: JSON.stringify([
          "Historic Character",
          "Hardwood Floors",
          "High Ceilings",
          "Walk to Parks",
          "Period Details",
        ]),
      },
      {
        title: "Spacious Ranch Home",
        description:
          "Single-story ranch home with 3 bedrooms and 2 bathrooms. Large living room with fireplace, updated kitchen, and attached garage. Perfect for those seeking single-level living.",
        price: 285000,
        property_type: "house",
        listing_type: "sale",
        bedrooms: 3,
        bathrooms: 2,
        square_feet: 1600,
        lot_size: 0.2,
        year_built: 1985,
        address: "321 Ranch Road",
        city: "Springfield",
        state: "IL",
        zip_code: "62704",
        latitude: 39.77,
        longitude: -89.67,
        images: JSON.stringify(["/placeholder.svg?height=400&width=600"]),
        features: JSON.stringify(["Single Level", "Fireplace", "Updated Kitchen", "Attached Garage", "Large Lot"]),
      },
      {
        title: "Luxury Apartment for Rent",
        description:
          "Brand new 1-bedroom luxury apartment with premium finishes. In-unit washer/dryer, walk-in closet, and access to building amenities including pool and fitness center.",
        price: 1800,
        property_type: "apartment",
        listing_type: "rent",
        bedrooms: 1,
        bathrooms: 1,
        square_feet: 900,
        year_built: 2023,
        address: "654 Luxury Lane",
        city: "Springfield",
        state: "IL",
        zip_code: "62705",
        latitude: 39.8,
        longitude: -89.63,
        images: JSON.stringify(["/placeholder.svg?height=400&width=600"]),
        features: JSON.stringify([
          "Luxury Finishes",
          "In-unit Laundry",
          "Pool Access",
          "Fitness Center",
          "Walk-in Closet",
        ]),
      },
      {
        title: "Investment Opportunity Townhouse",
        description:
          "3-bedroom townhouse in desirable neighborhood. Currently rented with good tenants. Great investment property with potential for appreciation.",
        price: 195000,
        property_type: "townhouse",
        listing_type: "sale",
        bedrooms: 3,
        bathrooms: 2.5,
        square_feet: 1400,
        year_built: 2005,
        address: "987 Investment Way",
        city: "Springfield",
        state: "IL",
        zip_code: "62706",
        latitude: 39.76,
        longitude: -89.68,
        images: JSON.stringify(["/placeholder.svg?height=400&width=600"]),
        features: JSON.stringify([
          "Investment Property",
          "Current Tenants",
          "Good Location",
          "Low Maintenance",
          "Appreciation Potential",
        ]),
      },
    ]

    // Insert properties
    for (const property of properties) {
      await connection.execute(
        `
        INSERT INTO properties (
          title, description, price, property_type, listing_type, bedrooms, bathrooms,
          square_feet, lot_size, year_built, address, city, state, zip_code,
          latitude, longitude, images, features, agent_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
        [
          property.title,
          property.description,
          property.price,
          property.property_type,
          property.listing_type,
          property.bedrooms,
          property.bathrooms,
          property.square_feet,
          property.lot_size,
          property.year_built,
          property.address,
          property.city,
          property.state,
          property.zip_code,
          property.latitude,
          property.longitude,
          property.images,
          property.features,
          agentId,
        ],
      )
    }

    // Create sample reviews for the agent
    const reviews = [
      {
        reviewer_name: "John Smith",
        reviewer_email: "john.smith@email.com",
        rating: 5,
        comment:
          "Sarah was absolutely fantastic to work with! She helped us find our dream home and made the entire process smooth and stress-free. Highly recommended!",
      },
      {
        reviewer_name: "Emily Davis",
        reviewer_email: "emily.davis@email.com",
        rating: 5,
        comment:
          "Professional, knowledgeable, and always available to answer questions. Sarah went above and beyond to help us sell our home quickly.",
      },
      {
        reviewer_name: "Michael Johnson",
        reviewer_email: "michael.johnson@email.com",
        rating: 4,
        comment:
          "Great experience working with Sarah. She knows the local market very well and provided excellent guidance throughout the buying process.",
      },
      {
        reviewer_name: "Lisa Wilson",
        reviewer_email: "lisa.wilson@email.com",
        rating: 5,
        comment:
          "Sarah is the best! She helped us find the perfect rental property and negotiated a great deal. We will definitely work with her again.",
      },
    ]

    // Insert reviews
    for (const review of reviews) {
      await connection.execute(
        `
        INSERT INTO reviews (agent_id, reviewer_name, reviewer_email, rating, comment)
        VALUES (?, ?, ?, ?, ?)
      `,
        [agentId, review.reviewer_name, review.reviewer_email, review.rating, review.comment],
      )
    }

    console.log("✅ Database seeding completed successfully!")
    console.log("👤 Created users:")
    console.log("   - Admin: admin@realestatepro.com / admin123")
    console.log("   - Agent: sarah@realestatepro.com / agent123")
    console.log("🏠 Created 6 sample properties")
    console.log("⭐ Created 4 agent reviews")
    console.log("")
    console.log("🚀 You can now start the development server with: npm run dev")
  } catch (error) {
    console.error("❌ Seeding failed:", error)
    process.exit(1)
  } finally {
    if (connection) {
      await connection.end()
    }
  }
}

// Run seeding
seedDatabase()
