import { type NextRequest, NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"

export async function authMiddleware(request: NextRequest) {
  const token = await getToken({ req: request })
  const { pathname } = request.nextUrl

  // Public routes that don't require authentication
  const publicRoutes = [
    "/",
    "/properties",
    "/agents",
    "/about",
    "/contact",
    "/blog",
    "/auth/login",
    "/auth/register",
    "/api/auth",
    "/api/properties",
    "/api/search",
    "/api/inquiries",
  ]

  // Check if the route is public or matches public patterns
  const isPublicRoute = publicRoutes.some(
    (route) =>
      pathname === route ||
      pathname.startsWith(route + "/") ||
      pathname.startsWith("/api/auth/") ||
      pathname.match(/^\/properties\/[^/]+$/), // Allow individual property pages
  )

  // Admin routes
  const adminRoutes = ["/admin"]
  const isAdminRoute = adminRoutes.some((route) => pathname.startsWith(route))

  // Agent routes
  const agentRoutes = ["/dashboard"]
  const isAgentRoute = agentRoutes.some((route) => pathname.startsWith(route))

  // Protected API routes
  const protectedApiRoutes = ["/api/protected"]
  const isProtectedApiRoute = protectedApiRoutes.some((route) => pathname.startsWith(route))

  // If it's a public route, allow access
  if (isPublicRoute && !isProtectedApiRoute) {
    return NextResponse.next()
  }

  // If user is not authenticated, redirect to login
  if (!token) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
    const loginUrl = new URL("/auth/login", request.url)
    loginUrl.searchParams.set("callbackUrl", pathname)
    return NextResponse.redirect(loginUrl)
  }

  // Check admin access
  if (isAdminRoute && token.role !== "admin") {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    return NextResponse.redirect(new URL("/", request.url))
  }

  // Check agent access (agents and admins can access)
  if (isAgentRoute && !["agent", "admin"].includes(token.role as string)) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }
    return NextResponse.redirect(new URL("/", request.url))
  }

  return NextResponse.next()
}

export function requireAuth(allowedRoles?: string[]) {
  return async (request: NextRequest) => {
    const token = await getToken({ req: request })

    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    if (allowedRoles && !allowedRoles.includes(token.role as string)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    return NextResponse.next()
  }
}
