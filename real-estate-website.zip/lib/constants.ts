export const PROPERTY_TYPES = ["House", "Apartment", "Condo", "Townhouse", "Commercial", "Land"] as const

export const LISTING_TYPES = ["For Sale", "For Rent"] as const

export const PROPERTY_STATUS = ["Active", "Pending", "Sold"] as const

export const PRICE_RANGES = [
  { label: "Under $300k", value: "under-300k", min: 0, max: 300000 },
  { label: "$300k - $500k", value: "300k-500k", min: 300000, max: 500000 },
  { label: "$500k - $750k", value: "500k-750k", min: 500000, max: 750000 },
  { label: "$750k - $1M", value: "750k-1m", min: 750000, max: 1000000 },
  { label: "Over $1M", value: "over-1m", min: 1000000, max: Number.POSITIVE_INFINITY },
] as const

export const SORT_OPTIONS = [
  { label: "Newest First", value: "newest" },
  { label: "Price: Low to High", value: "price-low" },
  { label: "Price: High to Low", value: "price-high" },
  { label: "Most Bedrooms", value: "beds" },
  { label: "Most Bathrooms", value: "baths" },
  { label: "Largest Square Footage", value: "sqft" },
] as const

export const PROPERTY_FEATURES = [
  "Swimming Pool",
  "Garage",
  "Garden",
  "Balcony",
  "Fireplace",
  "Air Conditioning",
  "Heating",
  "Hardwood Floors",
  "Granite Countertops",
  "Stainless Steel Appliances",
  "Walk-in Closet",
  "Security System",
  "High-speed Internet",
  "Gym/Fitness Center",
  "Laundry Room",
  "Storage Space",
  "Pet Friendly",
  "Furnished",
  "Dishwasher",
  "Microwave",
  "Refrigerator",
  "Washer/Dryer",
  "Cable Ready",
  "Ceiling Fans",
  "Deck/Patio",
  "Fenced Yard",
  "Hot Tub/Spa",
  "Jacuzzi",
  "Sauna",
  "Tennis Court",
  "Basketball Court",
  "Playground",
  "Clubhouse",
  "Business Center",
  "Concierge",
  "Doorman",
  "Elevator",
  "Wheelchair Accessible",
] as const

export const US_STATES = [
  { code: "AL", name: "Alabama" },
  { code: "AK", name: "Alaska" },
  { code: "AZ", name: "Arizona" },
  { code: "AR", name: "Arkansas" },
  { code: "CA", name: "California" },
  { code: "CO", name: "Colorado" },
  { code: "CT", name: "Connecticut" },
  { code: "DE", name: "Delaware" },
  { code: "FL", name: "Florida" },
  { code: "GA", name: "Georgia" },
  { code: "HI", name: "Hawaii" },
  { code: "ID", name: "Idaho" },
  { code: "IL", name: "Illinois" },
  { code: "IN", name: "Indiana" },
  { code: "IA", name: "Iowa" },
  { code: "KS", name: "Kansas" },
  { code: "KY", name: "Kentucky" },
  { code: "LA", name: "Louisiana" },
  { code: "ME", name: "Maine" },
  { code: "MD", name: "Maryland" },
  { code: "MA", name: "Massachusetts" },
  { code: "MI", name: "Michigan" },
  { code: "MN", name: "Minnesota" },
  { code: "MS", name: "Mississippi" },
  { code: "MO", name: "Missouri" },
  { code: "MT", name: "Montana" },
  { code: "NE", name: "Nebraska" },
  { code: "NV", name: "Nevada" },
  { code: "NH", name: "New Hampshire" },
  { code: "NJ", name: "New Jersey" },
  { code: "NM", name: "New Mexico" },
  { code: "NY", name: "New York" },
  { code: "NC", name: "North Carolina" },
  { code: "ND", name: "North Dakota" },
  { code: "OH", name: "Ohio" },
  { code: "OK", name: "Oklahoma" },
  { code: "OR", name: "Oregon" },
  { code: "PA", name: "Pennsylvania" },
  { code: "RI", name: "Rhode Island" },
  { code: "SC", name: "South Carolina" },
  { code: "SD", name: "South Dakota" },
  { code: "TN", name: "Tennessee" },
  { code: "TX", name: "Texas" },
  { code: "UT", name: "Utah" },
  { code: "VT", name: "Vermont" },
  { code: "VA", name: "Virginia" },
  { code: "WA", name: "Washington" },
  { code: "WV", name: "West Virginia" },
  { code: "WI", name: "Wisconsin" },
  { code: "WY", name: "Wyoming" },
] as const

export const BLOG_CATEGORIES = [
  "Buying Tips",
  "Selling Tips",
  "Market Analysis",
  "Investment",
  "Financing",
  "Home Improvement",
  "Legal",
  "Technology",
] as const

export const CONTACT_SUBJECTS = [
  "General Inquiry",
  "Property Viewing",
  "Buying Assistance",
  "Selling Property",
  "Investment Opportunities",
  "Market Analysis",
  "Technical Support",
  "Partnership",
] as const

export const COMPANY_INFO = {
  name: "RealEstate Pro",
  tagline: "Find Your Dream Home",
  description: "Professional real estate website with property listings and management",
  address: {
    street: "123 Real Estate Street",
    city: "Beverly Hills",
    state: "CA",
    zipCode: "90210",
    country: "United States",
  },
  contact: {
    phone: "(555) 123-4567",
    email: "info@realestatepro.com",
    website: "https://realestatepro.com",
  },
  social: {
    facebook: "https://facebook.com/realestatepro",
    twitter: "https://twitter.com/realestatepro",
    instagram: "https://instagram.com/realestatepro",
    linkedin: "https://linkedin.com/company/realestatepro",
  },
  businessHours: {
    monday: "9:00 AM - 6:00 PM",
    tuesday: "9:00 AM - 6:00 PM",
    wednesday: "9:00 AM - 6:00 PM",
    thursday: "9:00 AM - 6:00 PM",
    friday: "9:00 AM - 6:00 PM",
    saturday: "10:00 AM - 4:00 PM",
    sunday: "By Appointment Only",
  },
} as const

export const SEO_DEFAULTS = {
  title: "RealEstate Pro - Find Your Dream Home",
  description:
    "Professional real estate website with property listings and management. Find your perfect home with our expert agents and comprehensive property search.",
  keywords: "real estate, homes for sale, property listings, real estate agent, buy home, sell home, rent property",
  author: "RealEstate Pro",
  siteUrl: "https://realestatepro.com",
  image: "/og-image.jpg",
} as const

export const API_ENDPOINTS = {
  properties: "/api/properties",
  agents: "/api/agents",
  upload: "/api/upload",
  contact: "/api/contact",
  newsletter: "/api/newsletter",
  search: "/api/search",
} as const

export const IMAGE_CONFIG = {
  maxFileSize: 5 * 1024 * 1024, // 5MB
  allowedTypes: ["image/jpeg", "image/jpg", "image/png", "image/webp"],
  maxImages: 10,
  thumbnailSize: { width: 300, height: 200 },
  largeSize: { width: 1200, height: 800 },
} as const
