export interface User {
  id: string
  email: string
  password?: string
  name: string
  role: "admin" | "agent" | "user"
  phone?: string
  avatar?: string
  bio?: string
  license_number?: string
  years_experience?: number
  specializations?: string[]
  rating?: number
  total_reviews?: number
  created_at: Date
  updated_at: Date
}

export interface Property {
  id: string
  title: string
  description: string
  price: number
  property_type: "house" | "apartment" | "condo" | "townhouse" | "land" | "commercial"
  listing_type: "sale" | "rent"
  status: "active" | "pending" | "sold" | "rented"
  bedrooms?: number
  bathrooms?: number
  square_feet?: number
  lot_size?: number
  year_built?: number
  address: string
  city: string
  state: string
  zip_code: string
  latitude?: number
  longitude?: number
  images: string[]
  features: string[]
  agent_id: string
  views: number
  created_at: Date
  updated_at: Date
  // Joined fields from agent
  agent_name?: string
  agent_phone?: string
  agent_email?: string
  agent_avatar?: string
  agent_bio?: string
  agent_license?: string
  agent_rating?: number
  agent_total_reviews?: number
}

export interface Inquiry {
  id: string
  property_id?: string
  name: string
  email: string
  phone?: string
  message: string
  inquiry_type: "property" | "general" | "agent"
  status: "new" | "contacted" | "closed"
  agent_id?: string
  created_at: Date
  updated_at: Date
}

export interface Review {
  id: string
  agent_id: string
  reviewer_name: string
  reviewer_email: string
  rating: number
  comment?: string
  property_id?: string
  created_at: Date
}

export interface Favorite {
  id: string
  user_id: string
  property_id: string
  created_at: Date
}
