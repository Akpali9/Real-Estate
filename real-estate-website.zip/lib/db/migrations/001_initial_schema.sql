-- MySQL Database Schema for Real Estate Website

-- Users table
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255),
    name VARCHAR(255) NOT NULL,
    role ENUM('admin', 'agent', 'user') DEFAULT 'user',
    phone VARCHAR(20),
    avatar TEXT,
    bio TEXT,
    license_number VARCHAR(100),
    years_experience INT,
    specializations JSON,
    rating DECIMAL(3,2) DEFAULT 0,
    total_reviews INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_email (email),
    INDEX idx_users_role (role)
);

-- Properties table
CREATE TABLE properties (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(12,2) NOT NULL,
    property_type ENUM('house', 'apartment', 'condo', 'townhouse', 'land', 'commercial') NOT NULL,
    listing_type ENUM('sale', 'rent') NOT NULL,
    status ENUM('active', 'pending', 'sold', 'rented') DEFAULT 'active',
    bedrooms INT,
    bathrooms DECIMAL(3,1),
    square_feet INT,
    lot_size DECIMAL(10,2),
    year_built INT,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(50) NOT NULL,
    zip_code VARCHAR(10) NOT NULL,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    images JSON,
    features JSON,
    agent_id VARCHAR(36),
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_properties_price (price),
    INDEX idx_properties_type (property_type),
    INDEX idx_properties_listing_type (listing_type),
    INDEX idx_properties_status (status),
    INDEX idx_properties_agent (agent_id),
    INDEX idx_properties_city (city),
    INDEX idx_properties_created_at (created_at),
    INDEX idx_properties_location (latitude, longitude),
    FULLTEXT idx_properties_search (title, description, address)
);

-- Inquiries table
CREATE TABLE inquiries (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    property_id VARCHAR(36),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    message TEXT NOT NULL,
    inquiry_type ENUM('property', 'general', 'agent') DEFAULT 'property',
    status ENUM('new', 'contacted', 'closed') DEFAULT 'new',
    agent_id VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    FOREIGN KEY (agent_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_inquiries_property (property_id),
    INDEX idx_inquiries_agent (agent_id),
    INDEX idx_inquiries_status (status)
);

-- Reviews table
CREATE TABLE reviews (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    agent_id VARCHAR(36) NOT NULL,
    reviewer_name VARCHAR(255) NOT NULL,
    reviewer_email VARCHAR(255) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    property_id VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL,
    INDEX idx_reviews_agent (agent_id),
    UNIQUE KEY unique_agent_reviewer (agent_id, reviewer_email)
);

-- Favorites table
CREATE TABLE favorites (
    id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
    user_id VARCHAR(36) NOT NULL,
    property_id VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    INDEX idx_favorites_user (user_id),
    UNIQUE KEY unique_user_property (user_id, property_id)
);

-- Create trigger to update agent rating when review is added/updated/deleted
DELIMITER //

CREATE TRIGGER update_agent_rating_after_insert
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    UPDATE users 
    SET 
        rating = (SELECT AVG(rating) FROM reviews WHERE agent_id = NEW.agent_id),
        total_reviews = (SELECT COUNT(*) FROM reviews WHERE agent_id = NEW.agent_id)
    WHERE id = NEW.agent_id;
END//

CREATE TRIGGER update_agent_rating_after_update
AFTER UPDATE ON reviews
FOR EACH ROW
BEGIN
    UPDATE users 
    SET 
        rating = (SELECT AVG(rating) FROM reviews WHERE agent_id = NEW.agent_id),
        total_reviews = (SELECT COUNT(*) FROM reviews WHERE agent_id = NEW.agent_id)
    WHERE id = NEW.agent_id;
END//

CREATE TRIGGER update_agent_rating_after_delete
AFTER DELETE ON reviews
FOR EACH ROW
BEGIN
    UPDATE users 
    SET 
        rating = COALESCE((SELECT AVG(rating) FROM reviews WHERE agent_id = OLD.agent_id), 0),
        total_reviews = (SELECT COUNT(*) FROM reviews WHERE agent_id = OLD.agent_id)
    WHERE id = OLD.agent_id;
END//

DELIMITER ;
