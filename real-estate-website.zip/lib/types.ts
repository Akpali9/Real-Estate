export interface Property {
  id: number
  title: string
  price: string
  location: string
  address?: string
  beds: number
  baths: number
  sqft: string
  lotSize?: string
  yearBuilt?: number
  type: "For Sale" | "For Rent"
  status: "Active" | "Pending" | "Sold"
  image: string
  images?: string[]
  description: string
  dateAdded: string
  features?: string[]
  virtualTour?: string
  agent?: Agent
}

export interface Agent {
  id: number
  name: string
  title: string
  specialization: string
  experience: string
  phone: string
  email: string
  image: string
  rating: number
  reviews: number
  propertiesSold: number
  languages: string[]
  bio: string
  achievements: string[]
}

export interface BlogPost {
  id: number
  title: string
  excerpt: string
  content: string
  author: string
  date: string
  readTime: string
  category: string
  image: string
  featured: boolean
}

export interface ContactForm {
  firstName: string
  lastName: string
  email: string
  phone?: string
  subject: string
  message: string
  propertyType?: string
  budget?: string
}

export interface PropertyForm {
  title: string
  description: string
  propertyType: string
  listingType: string
  address: string
  city: string
  state: string
  zipCode: string
  price: string
  bedrooms: string
  bathrooms: string
  sqft: string
  lotSize: string
  yearBuilt: string
  features: string[]
  images: string[]
  contactName: string
  contactEmail: string
  contactPhone: string
  virtualTour: string
  openHouse: boolean
  agentListing: boolean
}

export interface User {
  id: string
  email: string
  name: string
  role: "user" | "agent" | "admin"
  phone?: string
  avatar?: string
  createdAt: string
  updatedAt: string
}

export interface SearchFilters {
  location?: string
  propertyType?: string
  priceRange?: string
  bedrooms?: number
  bathrooms?: number
  sortBy?: string
}

export interface PropertyStats {
  totalProperties: number
  activeListings: number
  totalValue: number
  pendingSales: number
}
