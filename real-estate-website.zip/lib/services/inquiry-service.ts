import { query } from "../db/connection"
import type { Inquiry } from "../db/schema"

export class InquiryService {
  static async createInquiry(inquiryData: {
    property_id?: string
    name: string
    email: string
    phone?: string
    message: string
    inquiry_type?: "property" | "general" | "agent"
    agent_id?: string
  }): Promise<Inquiry> {
    const sql = `
      INSERT INTO inquiries (
        property_id, name, email, phone, message, inquiry_type, agent_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `

    const values = [
      inquiryData.property_id,
      inquiryData.name,
      inquiryData.email,
      inquiryData.phone,
      inquiryData.message,
      inquiryData.inquiry_type || "property",
      inquiryData.agent_id,
    ]

    try {
      const result: any = await query(sql, values)
      const insertId = result.insertId

      const createdInquiry = await this.getInquiryById(insertId)
      if (!createdInquiry) {
        throw new Error("Failed to fetch created inquiry")
      }

      return createdInquiry
    } catch (error) {
      console.error("Error creating inquiry:", error)
      throw new Error("Failed to create inquiry")
    }
  }

  static async getInquiryById(id: string): Promise<Inquiry | null> {
    const sql = "SELECT * FROM inquiries WHERE id = ?"

    try {
      const result = await query(sql, [id])

      if (!Array.isArray(result) || result.length === 0) {
        return null
      }

      return result[0]
    } catch (error) {
      console.error("Error fetching inquiry:", error)
      throw new Error("Failed to fetch inquiry")
    }
  }

  static async getInquiriesByAgent(
    agentId: string,
    page = 1,
    limit = 20,
  ): Promise<{
    inquiries: Inquiry[]
    total: number
    totalPages: number
  }> {
    const offset = (page - 1) * limit

    const countSql = `
      SELECT COUNT(*) as total 
      FROM inquiries 
      WHERE agent_id = ? OR property_id IN (
        SELECT id FROM properties WHERE agent_id = ?
      )
    `

    const sql = `
      SELECT 
        i.*,
        p.title as property_title,
        p.address as property_address
      FROM inquiries i
      LEFT JOIN properties p ON i.property_id = p.id
      WHERE i.agent_id = ? OR i.property_id IN (
        SELECT id FROM properties WHERE agent_id = ?
      )
      ORDER BY i.created_at DESC
      LIMIT ? OFFSET ?
    `

    try {
      const [countResult, inquiriesResult] = await Promise.all([
        query(countSql, [agentId, agentId]),
        query(sql, [agentId, agentId, limit, offset]),
      ])

      const total = Array.isArray(countResult) ? countResult[0]?.total || 0 : 0
      const totalPages = Math.ceil(total / limit)
      const inquiries = Array.isArray(inquiriesResult) ? inquiriesResult : []

      return {
        inquiries,
        total,
        totalPages,
      }
    } catch (error) {
      console.error("Error fetching agent inquiries:", error)
      throw new Error("Failed to fetch inquiries")
    }
  }

  static async getAllInquiries(
    page = 1,
    limit = 20,
  ): Promise<{
    inquiries: Inquiry[]
    total: number
    totalPages: number
  }> {
    const offset = (page - 1) * limit

    const countSql = "SELECT COUNT(*) as total FROM inquiries"

    const sql = `
      SELECT 
        i.*,
        p.title as property_title,
        p.address as property_address,
        u.name as agent_name
      FROM inquiries i
      LEFT JOIN properties p ON i.property_id = p.id
      LEFT JOIN users u ON i.agent_id = u.id
      ORDER BY i.created_at DESC
      LIMIT ? OFFSET ?
    `

    try {
      const [countResult, inquiriesResult] = await Promise.all([query(countSql), query(sql, [limit, offset])])

      const total = Array.isArray(countResult) ? countResult[0]?.total || 0 : 0
      const totalPages = Math.ceil(total / limit)
      const inquiries = Array.isArray(inquiriesResult) ? inquiriesResult : []

      return {
        inquiries,
        total,
        totalPages,
      }
    } catch (error) {
      console.error("Error fetching all inquiries:", error)
      throw new Error("Failed to fetch inquiries")
    }
  }

  static async updateInquiryStatus(id: string, status: "new" | "contacted" | "closed"): Promise<Inquiry | null> {
    const sql = "UPDATE inquiries SET status = ? WHERE id = ?"

    try {
      await query(sql, [status, id])
      return await this.getInquiryById(id)
    } catch (error) {
      console.error("Error updating inquiry status:", error)
      throw new Error("Failed to update inquiry status")
    }
  }

  static async deleteInquiry(id: string): Promise<boolean> {
    const sql = "DELETE FROM inquiries WHERE id = ?"

    try {
      const result: any = await query(sql, [id])
      return result.affectedRows > 0
    } catch (error) {
      console.error("Error deleting inquiry:", error)
      throw new Error("Failed to delete inquiry")
    }
  }
}
