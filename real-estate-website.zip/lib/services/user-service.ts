import bcrypt from "bcryptjs"
import { query } from "../db/connection"
import type { User } from "../db/schema"

export class UserService {
  static async createUser(userData: {
    email: string
    password?: string
    name: string
    role?: "admin" | "agent" | "user"
    phone?: string
    bio?: string
    license_number?: string
    years_experience?: number
    specializations?: string[]
  }): Promise<User> {
    const hashedPassword = userData.password ? await bcrypt.hash(userData.password, 12) : null

    const sql = `
      INSERT INTO users (
        email, password, name, role, phone, bio, license_number, 
        years_experience, specializations
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `

    const values = [
      userData.email,
      hashedPassword,
      userData.name,
      userData.role || "user",
      userData.phone,
      userData.bio,
      userData.license_number,
      userData.years_experience,
      JSON.stringify(userData.specializations || []),
    ]

    try {
      const result: any = await query(sql, values)
      const insertId = result.insertId

      const createdUser = await this.getUserById(insertId)
      if (!createdUser) {
        throw new Error("Failed to fetch created user")
      }

      return createdUser
    } catch (error) {
      console.error("Error creating user:", error)
      throw new Error("Failed to create user")
    }
  }

  static async getUserById(id: string): Promise<User | null> {
    const sql = "SELECT * FROM users WHERE id = ?"

    try {
      const result = await query(sql, [id])

      if (!Array.isArray(result) || result.length === 0) {
        return null
      }

      const user = result[0]
      return {
        ...user,
        specializations:
          typeof user.specializations === "string"
            ? JSON.parse(user.specializations || "[]")
            : user.specializations || [],
      }
    } catch (error) {
      console.error("Error fetching user:", error)
      throw new Error("Failed to fetch user")
    }
  }

  static async getUserByEmail(email: string): Promise<User | null> {
    const sql = "SELECT * FROM users WHERE email = ?"

    try {
      const result = await query(sql, [email])

      if (!Array.isArray(result) || result.length === 0) {
        return null
      }

      const user = result[0]
      return {
        ...user,
        specializations:
          typeof user.specializations === "string"
            ? JSON.parse(user.specializations || "[]")
            : user.specializations || [],
      }
    } catch (error) {
      console.error("Error fetching user by email:", error)
      throw new Error("Failed to fetch user")
    }
  }

  static async validatePassword(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email)

    if (!user || !user.password) {
      return null
    }

    const isValid = await bcrypt.compare(password, user.password)

    if (!isValid) {
      return null
    }

    // Remove password from returned user object
    const { password: _, ...userWithoutPassword } = user
    return userWithoutPassword as User
  }

  static async updateUser(id: string, userData: Partial<User>): Promise<User | null> {
    const fields = Object.keys(userData).filter(
      (key) =>
        key !== "id" && key !== "created_at" && key !== "updated_at" && userData[key as keyof User] !== undefined,
    )

    if (fields.length === 0) {
      throw new Error("No fields to update")
    }

    // Hash password if provided
    if (userData.password) {
      userData.password = await bcrypt.hash(userData.password, 12)
    }

    const setClause = fields
      .map((field) => {
        if (field === "specializations") {
          return `${field} = ?`
        }
        return `${field} = ?`
      })
      .join(", ")

    const values = fields.map((field) => {
      const value = userData[field as keyof User]
      if (field === "specializations") {
        return JSON.stringify(value || [])
      }
      return value
    })

    const sql = `
      UPDATE users 
      SET ${setClause}
      WHERE id = ?
    `

    try {
      await query(sql, [...values, id])
      return await this.getUserById(id)
    } catch (error) {
      console.error("Error updating user:", error)
      throw new Error("Failed to update user")
    }
  }

  static async getAllAgents(): Promise<User[]> {
    const sql = `
      SELECT * FROM users 
      WHERE role = 'agent' 
      ORDER BY rating DESC, total_reviews DESC, name ASC
    `

    try {
      const result = await query(sql)

      if (!Array.isArray(result)) {
        return []
      }

      return result.map((user: any) => ({
        ...user,
        specializations:
          typeof user.specializations === "string"
            ? JSON.parse(user.specializations || "[]")
            : user.specializations || [],
      }))
    } catch (error) {
      console.error("Error fetching agents:", error)
      throw new Error("Failed to fetch agents")
    }
  }

  static async deleteUser(id: string): Promise<boolean> {
    const sql = "DELETE FROM users WHERE id = ?"

    try {
      const result: any = await query(sql, [id])
      return result.affectedRows > 0
    } catch (error) {
      console.error("Error deleting user:", error)
      throw new Error("Failed to delete user")
    }
  }
}
