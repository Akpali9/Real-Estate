import { query } from "../db/connection"
import type { Property } from "../db/schema"

export interface PropertyFilters {
  minPrice?: number
  maxPrice?: number
  propertyType?: string
  listingType?: "sale" | "rent"
  bedrooms?: number
  bathrooms?: number
  minSquareFeet?: number
  maxSquareFeet?: number
  city?: string
  state?: string
  features?: string[]
  latitude?: number
  longitude?: number
  radius?: number // in miles
}

export interface PropertySearchOptions {
  page?: number
  limit?: number
  sortBy?: "price" | "created_at" | "views" | "square_feet"
  sortOrder?: "asc" | "desc"
  search?: string
}

export class PropertyService {
  static async getAllProperties(
    filters: PropertyFilters = {},
    options: PropertySearchOptions = {},
  ): Promise<{ properties: Property[]; total: number; totalPages: number }> {
    const { page = 1, limit = 12, sortBy = "created_at", sortOrder = "desc", search } = options

    const offset = (page - 1) * limit
    const whereConditions: string[] = ["p.status = 'active'"]
    const queryParams: any[] = []

    // Build WHERE conditions
    if (filters.minPrice) {
      whereConditions.push("p.price >= ?")
      queryParams.push(filters.minPrice)
    }

    if (filters.maxPrice) {
      whereConditions.push("p.price <= ?")
      queryParams.push(filters.maxPrice)
    }

    if (filters.propertyType) {
      whereConditions.push("p.property_type = ?")
      queryParams.push(filters.propertyType)
    }

    if (filters.listingType) {
      whereConditions.push("p.listing_type = ?")
      queryParams.push(filters.listingType)
    }

    if (filters.bedrooms) {
      whereConditions.push("p.bedrooms >= ?")
      queryParams.push(filters.bedrooms)
    }

    if (filters.bathrooms) {
      whereConditions.push("p.bathrooms >= ?")
      queryParams.push(filters.bathrooms)
    }

    if (filters.minSquareFeet) {
      whereConditions.push("p.square_feet >= ?")
      queryParams.push(filters.minSquareFeet)
    }

    if (filters.maxSquareFeet) {
      whereConditions.push("p.square_feet <= ?")
      queryParams.push(filters.maxSquareFeet)
    }

    if (filters.city) {
      whereConditions.push("LOWER(p.city) = LOWER(?)")
      queryParams.push(filters.city)
    }

    if (filters.state) {
      whereConditions.push("LOWER(p.state) = LOWER(?)")
      queryParams.push(filters.state)
    }

    if (filters.features && filters.features.length > 0) {
      const featureConditions = filters.features.map(() => "JSON_CONTAINS(p.features, JSON_QUOTE(?))").join(" AND ")
      whereConditions.push(`(${featureConditions})`)
      queryParams.push(...filters.features)
    }

    // Geographic search using Haversine formula
    if (filters.latitude && filters.longitude && filters.radius) {
      whereConditions.push(`
        (6371 * acos(cos(radians(?)) * cos(radians(p.latitude)) * 
        cos(radians(p.longitude) - radians(?)) + sin(radians(?)) * 
        sin(radians(p.latitude)))) <= ?
      `)
      queryParams.push(filters.latitude, filters.longitude, filters.latitude, filters.radius * 1.60934) // Convert miles to km
    }

    // Full-text search
    if (search) {
      whereConditions.push(`
        (MATCH(p.title, p.description, p.address) AGAINST(? IN NATURAL LANGUAGE MODE) OR 
         LOWER(p.title) LIKE LOWER(?) OR 
         LOWER(p.description) LIKE LOWER(?) OR 
         LOWER(p.address) LIKE LOWER(?) OR 
         LOWER(p.city) LIKE LOWER(?))
      `)
      const searchPattern = `%${search}%`
      queryParams.push(search, searchPattern, searchPattern, searchPattern, searchPattern)
    }

    const whereClause = whereConditions.length > 0 ? `WHERE ${whereConditions.join(" AND ")}` : ""

    // Count query
    const countQuery = `
      SELECT COUNT(*) as total
      FROM properties p
      LEFT JOIN users u ON p.agent_id = u.id
      ${whereClause}
    `

    // Main query
    const mainQuery = `
      SELECT 
        p.*,
        u.name as agent_name,
        u.phone as agent_phone,
        u.email as agent_email,
        u.avatar as agent_avatar,
        u.bio as agent_bio,
        u.license_number as agent_license,
        u.rating as agent_rating,
        u.total_reviews as agent_total_reviews
      FROM properties p
      LEFT JOIN users u ON p.agent_id = u.id
      ${whereClause}
      ORDER BY p.${sortBy} ${sortOrder.toUpperCase()}
      LIMIT ? OFFSET ?
    `

    try {
      const [countResult, propertiesResult] = await Promise.all([
        query(countQuery, queryParams),
        query(mainQuery, [...queryParams, limit, offset]),
      ])

      const total = Array.isArray(countResult) ? countResult[0]?.total || 0 : 0
      const totalPages = Math.ceil(total / limit)

      // Parse JSON fields
      const properties = Array.isArray(propertiesResult)
        ? propertiesResult.map((property: any) => ({
            ...property,
            images: typeof property.images === "string" ? JSON.parse(property.images || "[]") : property.images || [],
            features:
              typeof property.features === "string" ? JSON.parse(property.features || "[]") : property.features || [],
          }))
        : []

      return {
        properties,
        total,
        totalPages,
      }
    } catch (error) {
      console.error("Error fetching properties:", error)
      throw new Error("Failed to fetch properties")
    }
  }

  static async getPropertyById(id: string): Promise<Property | null> {
    const sql = `
      SELECT 
        p.*,
        u.name as agent_name,
        u.phone as agent_phone,
        u.email as agent_email,
        u.avatar as agent_avatar,
        u.bio as agent_bio,
        u.license_number as agent_license,
        u.rating as agent_rating,
        u.total_reviews as agent_total_reviews
      FROM properties p
      LEFT JOIN users u ON p.agent_id = u.id
      WHERE p.id = ?
    `

    try {
      const result = await query(sql, [id])

      if (!Array.isArray(result) || result.length === 0) {
        return null
      }

      // Increment view count
      await query("UPDATE properties SET views = views + 1 WHERE id = ?", [id])

      const property = result[0]

      // Parse JSON fields
      return {
        ...property,
        images: typeof property.images === "string" ? JSON.parse(property.images || "[]") : property.images || [],
        features:
          typeof property.features === "string" ? JSON.parse(property.features || "[]") : property.features || [],
      }
    } catch (error) {
      console.error("Error fetching property:", error)
      throw new Error("Failed to fetch property")
    }
  }

  static async createProperty(
    propertyData: Omit<Property, "id" | "views" | "created_at" | "updated_at">,
  ): Promise<Property> {
    const sql = `
      INSERT INTO properties (
        title, description, price, property_type, listing_type, status,
        bedrooms, bathrooms, square_feet, lot_size, year_built,
        address, city, state, zip_code, latitude, longitude,
        images, features, agent_id
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      )
    `

    const values = [
      propertyData.title,
      propertyData.description,
      propertyData.price,
      propertyData.property_type,
      propertyData.listing_type,
      propertyData.status || "active",
      propertyData.bedrooms,
      propertyData.bathrooms,
      propertyData.square_feet,
      propertyData.lot_size,
      propertyData.year_built,
      propertyData.address,
      propertyData.city,
      propertyData.state,
      propertyData.zip_code,
      propertyData.latitude,
      propertyData.longitude,
      JSON.stringify(propertyData.images || []),
      JSON.stringify(propertyData.features || []),
      propertyData.agent_id,
    ]

    try {
      const result: any = await query(sql, values)
      const insertId = result.insertId

      // Fetch the created property
      const createdProperty = await this.getPropertyById(insertId)
      if (!createdProperty) {
        throw new Error("Failed to fetch created property")
      }

      return createdProperty
    } catch (error) {
      console.error("Error creating property:", error)
      throw new Error("Failed to create property")
    }
  }

  static async updateProperty(id: string, propertyData: Partial<Property>): Promise<Property | null> {
    const fields = Object.keys(propertyData).filter(
      (key) =>
        key !== "id" &&
        key !== "created_at" &&
        key !== "updated_at" &&
        !key.startsWith("agent_") &&
        propertyData[key as keyof Property] !== undefined,
    )

    if (fields.length === 0) {
      throw new Error("No fields to update")
    }

    const setClause = fields
      .map((field) => {
        if (field === "images" || field === "features") {
          return `${field} = ?`
        }
        return `${field} = ?`
      })
      .join(", ")

    const values = fields.map((field) => {
      const value = propertyData[field as keyof Property]
      if (field === "images" || field === "features") {
        return JSON.stringify(value || [])
      }
      return value
    })

    const sql = `
      UPDATE properties 
      SET ${setClause}
      WHERE id = ?
    `

    try {
      await query(sql, [...values, id])
      return await this.getPropertyById(id)
    } catch (error) {
      console.error("Error updating property:", error)
      throw new Error("Failed to update property")
    }
  }

  static async deleteProperty(id: string): Promise<boolean> {
    const sql = "DELETE FROM properties WHERE id = ?"

    try {
      const result: any = await query(sql, [id])
      return result.affectedRows > 0
    } catch (error) {
      console.error("Error deleting property:", error)
      throw new Error("Failed to delete property")
    }
  }

  static async getFeaturedProperties(limit = 6): Promise<Property[]> {
    const sql = `
      SELECT 
        p.*,
        u.name as agent_name,
        u.phone as agent_phone,
        u.email as agent_email,
        u.avatar as agent_avatar
      FROM properties p
      LEFT JOIN users u ON p.agent_id = u.id
      WHERE p.status = 'active'
      ORDER BY p.views DESC, p.created_at DESC
      LIMIT ?
    `

    try {
      const result = await query(sql, [limit])

      if (!Array.isArray(result)) {
        return []
      }

      return result.map((property: any) => ({
        ...property,
        images: typeof property.images === "string" ? JSON.parse(property.images || "[]") : property.images || [],
        features:
          typeof property.features === "string" ? JSON.parse(property.features || "[]") : property.features || [],
      }))
    } catch (error) {
      console.error("Error fetching featured properties:", error)
      throw new Error("Failed to fetch featured properties")
    }
  }

  static async getPropertiesByAgent(agentId: string, limit?: number): Promise<Property[]> {
    let sql = `
      SELECT * FROM properties 
      WHERE agent_id = ? AND status = 'active'
      ORDER BY created_at DESC
    `

    const params = [agentId]

    if (limit) {
      sql += ` LIMIT ?`
      params.push(limit)
    }

    try {
      const result = await query(sql, params)

      if (!Array.isArray(result)) {
        return []
      }

      return result.map((property: any) => ({
        ...property,
        images: typeof property.images === "string" ? JSON.parse(property.images || "[]") : property.images || [],
        features:
          typeof property.features === "string" ? JSON.parse(property.features || "[]") : property.features || [],
      }))
    } catch (error) {
      console.error("Error fetching agent properties:", error)
      throw new Error("Failed to fetch agent properties")
    }
  }

  static async searchProperties(searchTerm: string, limit = 10): Promise<Property[]> {
    const sql = `
      SELECT 
        p.*,
        u.name as agent_name,
        MATCH(p.title, p.description, p.address) AGAINST(? IN NATURAL LANGUAGE MODE) as relevance
      FROM properties p
      LEFT JOIN users u ON p.agent_id = u.id
      WHERE p.status = 'active' AND (
        MATCH(p.title, p.description, p.address) AGAINST(? IN NATURAL LANGUAGE MODE) OR
        LOWER(p.title) LIKE LOWER(?) OR
        LOWER(p.city) LIKE LOWER(?) OR
        LOWER(p.address) LIKE LOWER(?)
      )
      ORDER BY relevance DESC, p.created_at DESC
      LIMIT ?
    `

    const searchPattern = `%${searchTerm}%`

    try {
      const result = await query(sql, [searchTerm, searchTerm, searchPattern, searchPattern, searchPattern, limit])

      if (!Array.isArray(result)) {
        return []
      }

      return result.map((property: any) => ({
        ...property,
        images: typeof property.images === "string" ? JSON.parse(property.images || "[]") : property.images || [],
        features:
          typeof property.features === "string" ? JSON.parse(property.features || "[]") : property.features || [],
      }))
    } catch (error) {
      console.error("Error searching properties:", error)
      throw new Error("Failed to search properties")
    }
  }
}
