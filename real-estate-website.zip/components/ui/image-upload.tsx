"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "./button"
import { Card, CardContent } from "./card"
import { Upload, X } from "lucide-react"
import Image from "next/image"
import { upload } from "@vercel/blob/client"
import { cn } from "@/lib/utils"

interface ImageUploadProps {
  onUpload: (urls: string[]) => void
  maxImages?: number
  existingImages?: string[]
  className?: string
}

export function ImageUpload({ onUpload, maxImages = 10, existingImages = [], className }: ImageUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [images, setImages] = useState<string[]>(existingImages)

  const handleFileUpload = useCallback(
    async (files: FileList) => {
      if (!files || files.length === 0) return

      setUploading(true)
      try {
        const uploadPromises = Array.from(files).map(async (file) => {
          const blob = await upload(file.name, file, {
            access: "public",
            handleUploadUrl: "/api/upload",
          })
          return blob.url
        })

        const uploadedUrls = await Promise.all(uploadPromises)
        const newImages = [...images, ...uploadedUrls].slice(0, maxImages)
        setImages(newImages)
        onUpload(newImages)
      } catch (error) {
        console.error("Upload failed:", error)
      } finally {
        setUploading(false)
      }
    },
    [images, maxImages, onUpload],
  )

  const removeImage = useCallback(
    (index: number) => {
      const newImages = images.filter((_, i) => i !== index)
      setImages(newImages)
      onUpload(newImages)
    },
    [images, onUpload],
  )

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      const files = e.dataTransfer.files
      if (files) handleFileUpload(files)
    },
    [handleFileUpload],
  )

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
  }, [])

  return (
    <div className={cn("space-y-4", className)}>
      <Card
        className="border-2 border-dashed border-gray-300 hover:border-gray-400 transition-colors"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        <CardContent className="p-6 text-center">
          <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">Drag and drop images here, or click to select files</p>
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
            className="hidden"
            id="image-upload"
            disabled={uploading || images.length >= maxImages}
          />
          <label htmlFor="image-upload">
            <Button type="button" variant="outline" disabled={uploading || images.length >= maxImages} asChild>
              <span>{uploading ? "Uploading..." : "Select Images"}</span>
            </Button>
          </label>
          <p className="text-sm text-gray-500 mt-2">
            {images.length}/{maxImages} images uploaded
          </p>
        </CardContent>
      </Card>

      {images.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {images.map((image, index) => (
            <div key={index} className="relative group">
              <Image
                src={image || "/placeholder.svg"}
                alt={`Upload ${index + 1}`}
                width={200}
                height={150}
                className="w-full h-32 object-cover rounded-lg"
              />
              <button
                type="button"
                onClick={() => removeImage(index)}
                className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="h-4 w-4" />
              </button>
              {index === 0 && (
                <div className="absolute bottom-2 left-2 bg-blue-600 text-white text-xs px-2 py-1 rounded">Main</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
