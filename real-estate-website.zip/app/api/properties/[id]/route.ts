import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { PropertyService } from "@/lib/services/property-service"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const property = await PropertyService.getPropertyById(params.id)

    if (!property) {
      return NextResponse.json({ error: "Property not found" }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      data: property,
    })
  } catch (error) {
    console.error("Error fetching property:", error)
    return NextResponse.json({ error: "Failed to fetch property" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !["agent", "admin"].includes(session.user.role)) {
      return NextResponse.json({ error: "Unauthorized - Agent or Admin access required" }, { status: 401 })
    }

    // Check if property exists and user has permission
    const existingProperty = await PropertyService.getPropertyById(params.id)
    if (!existingProperty) {
      return NextResponse.json({ error: "Property not found" }, { status: 404 })
    }

    // Agents can only edit their own properties
    if (session.user.role === "agent" && existingProperty.agent_id !== session.user.id) {
      return NextResponse.json({ error: "You can only edit your own properties" }, { status: 403 })
    }

    const body = await request.json()
    const updatedProperty = await PropertyService.updateProperty(params.id, body)

    return NextResponse.json({
      success: true,
      data: updatedProperty,
      message: "Property updated successfully",
    })
  } catch (error) {
    console.error("Error updating property:", error)
    return NextResponse.json({ error: "Failed to update property" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !["agent", "admin"].includes(session.user.role)) {
      return NextResponse.json({ error: "Unauthorized - Agent or Admin access required" }, { status: 401 })
    }

    // Check if property exists and user has permission
    const existingProperty = await PropertyService.getPropertyById(params.id)
    if (!existingProperty) {
      return NextResponse.json({ error: "Property not found" }, { status: 404 })
    }

    // Agents can only delete their own properties
    if (session.user.role === "agent" && existingProperty.agent_id !== session.user.id) {
      return NextResponse.json({ error: "You can only delete your own properties" }, { status: 403 })
    }

    const deleted = await PropertyService.deleteProperty(params.id)

    if (!deleted) {
      return NextResponse.json({ error: "Failed to delete property" }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Property deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting property:", error)
    return NextResponse.json({ error: "Failed to delete property" }, { status: 500 })
  }
}
