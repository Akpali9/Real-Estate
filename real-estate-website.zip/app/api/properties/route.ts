import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { PropertyService } from "@/lib/services/property-service"
import { z } from "zod"

const propertySchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  price: z.number().positive("Price must be positive"),
  property_type: z.enum(["house", "apartment", "condo", "townhouse", "land", "commercial"]),
  listing_type: z.enum(["sale", "rent"]),
  status: z.enum(["active", "pending", "sold", "rented"]).optional(),
  bedrooms: z.number().optional(),
  bathrooms: z.number().optional(),
  square_feet: z.number().optional(),
  lot_size: z.number().optional(),
  year_built: z.number().optional(),
  address: z.string().min(1, "Address is required"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  zip_code: z.string().min(1, "ZIP code is required"),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
  images: z.array(z.string()).optional(),
  features: z.array(z.string()).optional(),
  agent_id: z.string().min(1, "Agent ID is required"),
})

const filtersSchema = z.object({
  page: z.string().optional(),
  limit: z.string().optional(),
  search: z.string().optional(),
  minPrice: z.string().optional(),
  maxPrice: z.string().optional(),
  propertyType: z.string().optional(),
  listingType: z.enum(["sale", "rent"]).optional(),
  bedrooms: z.string().optional(),
  bathrooms: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  sortBy: z.enum(["price", "created_at", "views", "square_feet"]).optional(),
  sortOrder: z.enum(["asc", "desc"]).optional(),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const rawFilters = Object.fromEntries(searchParams.entries())

    // Validate and parse filters
    const validatedFilters = filtersSchema.parse(rawFilters)

    const filters = {
      minPrice: validatedFilters.minPrice ? Number.parseFloat(validatedFilters.minPrice) : undefined,
      maxPrice: validatedFilters.maxPrice ? Number.parseFloat(validatedFilters.maxPrice) : undefined,
      propertyType: validatedFilters.propertyType,
      listingType: validatedFilters.listingType,
      bedrooms: validatedFilters.bedrooms ? Number.parseInt(validatedFilters.bedrooms) : undefined,
      bathrooms: validatedFilters.bathrooms ? Number.parseFloat(validatedFilters.bathrooms) : undefined,
      city: validatedFilters.city,
      state: validatedFilters.state,
    }

    const options = {
      page: validatedFilters.page ? Number.parseInt(validatedFilters.page) : 1,
      limit: validatedFilters.limit ? Number.parseInt(validatedFilters.limit) : 12,
      search: validatedFilters.search,
      sortBy: validatedFilters.sortBy || "created_at",
      sortOrder: validatedFilters.sortOrder || "desc",
    }

    const result = await PropertyService.getAllProperties(filters, options)

    return NextResponse.json({
      success: true,
      data: result,
    })
  } catch (error) {
    console.error("Error fetching properties:", error)

    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid filters", details: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Failed to fetch properties" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !["agent", "admin"].includes(session.user.role)) {
      return NextResponse.json({ error: "Unauthorized - Agent or Admin access required" }, { status: 401 })
    }

    const body = await request.json()

    // Validate input
    const validatedData = propertySchema.parse(body)

    // Ensure agent can only create properties for themselves (unless admin)
    if (session.user.role === "agent" && validatedData.agent_id !== session.user.id) {
      return NextResponse.json({ error: "Agents can only create properties for themselves" }, { status: 403 })
    }

    const property = await PropertyService.createProperty(validatedData)

    return NextResponse.json({
      success: true,
      data: property,
      message: "Property created successfully",
    })
  } catch (error) {
    console.error("Error creating property:", error)

    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Failed to create property" }, { status: 500 })
  }
}
