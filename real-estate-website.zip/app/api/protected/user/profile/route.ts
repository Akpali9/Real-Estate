import { type NextRequest, NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"
import { z } from "zod"
import { UserService } from "@/lib/services/user-service"

const updateProfileSchema = z.object({
  name: z.string().min(1).optional(),
  phone: z.string().optional(),
  bio: z.string().optional(),
  avatar: z.string().url().optional(),
  license_number: z.string().optional(),
  years_experience: z.number().min(0).optional(),
  specializations: z.array(z.string()).optional(),
})

export async function GET(request: NextRequest) {
  try {
    const token = await getToken({ req: request })

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized",
        },
        { status: 401 },
      )
    }

    const user = await UserService.getUserById(token.sub!)

    if (!user) {
      return NextResponse.json(
        {
          success: false,
          message: "User not found",
        },
        { status: 404 },
      )
    }

    // Get user stats if they're an agent
    let stats = null
    if (user.role === "agent") {
      stats = await UserService.getUserStats(user.id)
    }

    return NextResponse.json({
      success: true,
      data: {
        user,
        stats,
      },
    })
  } catch (error) {
    console.error("Error fetching user profile:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to fetch profile",
      },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest) {
  try {
    const token = await getToken({ req: request })

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized",
        },
        { status: 401 },
      )
    }

    const body = await request.json()
    const validatedData = updateProfileSchema.parse(body)

    const updatedUser = await UserService.updateUser(token.sub!, validatedData)

    if (!updatedUser) {
      return NextResponse.json(
        {
          success: false,
          message: "Failed to update profile",
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Profile updated successfully",
      data: updatedUser,
    })
  } catch (error: any) {
    console.error("Error updating profile:", error)

    if (error.name === "ZodError") {
      return NextResponse.json(
        {
          success: false,
          message: "Validation error",
          errors: error.errors,
        },
        { status: 400 },
      )
    }

    return NextResponse.json(
      {
        success: false,
        message: "Failed to update profile",
      },
      { status: 500 },
    )
  }
}
