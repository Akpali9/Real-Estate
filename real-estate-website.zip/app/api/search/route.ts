import { type NextRequest, NextResponse } from "next/server"
import { PropertyService } from "@/lib/services/property-service"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    if (!query) {
      return NextResponse.json({ error: "Search query is required" }, { status: 400 })
    }

    const properties = await PropertyService.searchProperties(query, limit)

    return NextResponse.json({
      success: true,
      data: properties,
      query,
    })
  } catch (error) {
    console.error("Error searching properties:", error)
    return NextResponse.json({ error: "Failed to search properties" }, { status: 500 })
  }
}
