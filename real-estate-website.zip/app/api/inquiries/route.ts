import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth/config"
import { InquiryService } from "@/lib/services/inquiry-service"
import { z } from "zod"

const inquirySchema = z.object({
  property_id: z.string().optional(),
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  message: z.string().min(1, "Message is required"),
  inquiry_type: z.enum(["property", "general", "agent"]).optional(),
  agent_id: z.string().optional(),
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate input
    const validatedData = inquirySchema.parse(body)

    const inquiry = await InquiryService.createInquiry(validatedData)

    return NextResponse.json({
      success: true,
      data: inquiry,
      message: "Inquiry submitted successfully",
    })
  } catch (error) {
    console.error("Error creating inquiry:", error)

    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: "Validation failed", details: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Failed to submit inquiry" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !["agent", "admin"].includes(session.user.role)) {
      return NextResponse.json({ error: "Unauthorized - Agent or Admin access required" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "20")

    let result

    if (session.user.role === "admin") {
      result = await InquiryService.getAllInquiries(page, limit)
    } else {
      result = await InquiryService.getInquiriesByAgent(session.user.id, page, limit)
    }

    return NextResponse.json({
      success: true,
      data: result,
    })
  } catch (error) {
    console.error("Error fetching inquiries:", error)
    return NextResponse.json({ error: "Failed to fetch inquiries" }, { status: 500 })
  }
}
