import type { MetadataRoute } from "next"
import { COMPANY_INFO } from "@/lib/constants"

export default function robots(): MetadataRoute.Robots {
  const baseUrl = COMPANY_INFO.contact.website

  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/admin/", "/api/", "/private/"],
    },
    sitemap: `${baseUrl}/sitemap.xml`,
  }
}
